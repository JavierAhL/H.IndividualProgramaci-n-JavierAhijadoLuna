<?php
session_start();
// Recoger los datos del formulario
$correo = $_POST['email'];
$password = $_POST['password'];
$titulo = $_POST['title'];
$contenido = $_POST['content'];
$fecha = $_POST['fecha'];
$autor = $_POST['autor'];
$imagen = $_POST['imagen'];


